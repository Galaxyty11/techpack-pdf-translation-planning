---
name: pdf-bilingual-annotator
description: 识别PDF中的英文文本，调用LLM翻译为中文，以FreeText注释+红色字体方式标注在原文旁边空白处。适用于服装图纸、工艺单等轻工纺织定制需求文档的翻译标注。当用户要求「翻译PDF」「给PDF加中文标注」「图纸翻译」「PDF双语标注」时使用。
---

# PDF Bilingual Annotator

将PDF中的英文文本翻译为中文，以红色FreeText注释形式标注在原文旁边。

## 触发词

- 翻译PDF / translate PDF
- 图纸翻译
- PDF加中文标注 / PDF双语标注
- 红色批注翻译

## 工作流程

### 前置检查（每次执行前自动完成）

1. **检查 Python 环境**：

```bash
python3 --version
```

- 如果命令不存在或报错，自动安装 Python：
  - macOS: `brew install python3`
  - Linux: `sudo apt-get install python3 python3-pip`
  - Windows: 提示用户从 https://www.python.org 下载安装

2. **检查 pip 依赖**：

```bash
python3 -c "import fitz; import openai; import dashscope" 2>/dev/null || pip install pymupdf openai dashscope
```

3. **检查百炼环境变量**：

```bash
echo $DASHSCOPE_API_KEY
```

- 如果 `DASHSCOPE_API_KEY` 为空或未设置，**停止执行**并提示用户：
  > 请先配置百炼 API Key 环境变量：
  > ```bash
  > export DASHSCOPE_API_KEY=your_api_key_here
  > ```
  > 获取方式：登录 [百炼控制台](https://dashscope.console.aliyun.com/) → API-KEY 管理 → 创建/复制 Key
  >
  > 建议写入 shell 配置文件（如 `~/.zshrc` 或 `~/.bashrc`）使其永久生效。

---

### Mode 1: Translate（默认）

执行翻译标注全流程：

1. **确认输入**：确定待处理的PDF文件路径和页码范围
2. **运行脚本**：

```bash
python scripts/translate_pdf.py <input.pdf> [--pages 1-5] [--output translated.pdf]
```

3. **验证效果**：将输出PDF渲染为图片检查排版

```python
import fitz
doc = fitz.open("output.pdf")
page = doc[0]
pix = page.get_pixmap(matrix=fitz.Matrix(2, 2))
pix.save("preview.png")
```

### Mode 2: Preview（预览）

仅提取文本和位置，不写入注释，用于确认翻译内容：

```bash
python scripts/translate_pdf.py <input.pdf> --preview
```

## 参数说明

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `input` | 输入PDF路径 | 必填 |
| `--output` | 输出PDF路径 | `{input}_translated.pdf` |
| `--pages` | 页码范围（如 `1-5` 或 `1,3,5`） | 全部页 |
| `--font-size` | 注释字号 | 7（自适应） |
| `--preview` | 仅预览不写入 | False |
| `--batch-size` | LLM批量翻译条数 | 20 |

## 翻译规则

1. 页脚内容不翻译（页面底部10%区域 + 含"Proprietary"/"Printed:"等关键词）
2. 纯数字/编号不翻译（如尺寸数值、色号TCX等）
3. 人名不翻译
4. 已有中文的文本块跳过

## 排版规则

1. 译文优先放在原文右侧空白处
2. 右侧空间不足时尝试下方、左侧
3. 不得与已有文本、图片、表格线重叠
4. 长译文自动换行，字号可自适应缩小（最小5pt）
5. 注释背景透明，仅显示红色文字

## 依赖

- Python 3.8+
- `pymupdf` (fitz)
- `openai` (用于调用DashScope兼容API)
- 环境变量 `DASHSCOPE_API_KEY`

安装：
```bash
pip install pymupdf openai
```

## 注意事项

- LLM模型固定使用 `qwen3.6-flash`，通过DashScope OpenAI兼容接口调用，不开启深度思考
- 脚本兼容 Windows / macOS / Linux
- 如果 DASHSCOPE_API_KEY 未设置，脚本会报错退出（不静默兜底）
- 大文件建议分批处理（每次10-20页）以控制API调用量
