"""
PDF Bilingual Annotator - 核心处理脚本
识别PDF英文文本 → LLM翻译 → FreeText红色注释标注

用法:
    python translate_pdf.py input.pdf [--pages 1-5] [--output out.pdf] [--preview]
"""

import argparse
import base64
import json
import os
import re
import sys
from pathlib import Path

try:
    import fitz  # PyMuPDF
except ImportError:
    print("错误: 请先安装 pymupdf: pip install pymupdf")
    sys.exit(1)

try:
    import openai
except ImportError:
    print("错误: 请先安装 openai: pip install openai")
    sys.exit(1)

try:
    import dashscope
    from dashscope import MultiModalConversation
except ImportError:
    print("错误: 请先安装 dashscope: pip install dashscope")
    sys.exit(1)


# ============ 配置 ============
LLM_MODEL = "qwen3.6-flash"
OCR_MODEL = "qwen3.5-ocr"  # OCR 模型
LLM_BASE_URL = "https://dashscope.aliyuncs.com/compatible-mode/v1"
DEFAULT_FONT_SIZE = 7
MIN_FONT_SIZE = 5
RED_COLOR = (1, 0, 0)
ANNOTATION_FONT = "china-s"  # PyMuPDF 内置中文字体

# LLM Prompt
SYSTEM_PROMPT = (
    "你是服装纺织行业的英中翻译专家，精通拉链、辅料、缝制工艺、版型测量等专业术语。"
    "翻译时必须使用行业通用的中文术语，禁止逐词直译。"
    "表头标签、产品描述名称、工艺说明都要翻译。"
    "只有纯人名和纯字母数字编码才不翻译。"
)

FEW_SHOT_USER = (
    "将以下英文短语翻译为简洁中文，每行一个结果，只输出译文，不要编号和解释。\n"
    "规则：\n"
    "- 纯人名（如 Jackie Gumm）保持原文，输出 SKIP\n"
    "- 纯字母数字编码/型号（如 M654、F27、KENN-A）输出 SKIP\n"
    "- 表头标签（如 STYLE NAME:、SIZE RANGE:）必须翻译\n"
    "- 产品名称含描述词汇（如 WINTER PANT）必须翻译\n\n"
    "1. #5 reversed coil zip close end, DA8BLH slider\n"
    "2. SN topstitch bottom edge\n"
    "3. Front Welt Pocket Opening\n"
    "4. COVER PAGE\n"
    "5. STYLE NAME:\n"
    "6. MENS GRIDIRON WINTER PANT GSB COMMENTS 6.12.26\n"
    "7. SEASON | YEAR:\n"
    "8. AD LEAD:\n"
    "9. Jackie Gumm\n"
    "10. M654"
)

FEW_SHOT_ASSISTANT = (
    "5号反穿尼龙闭尾拉链，DA8BLH拉头\n"
    "单针明线底边\n"
    "前嵌线袋开口\n"
    "封面页\n"
    "款式名称：\n"
    "男款钢筋冬季裤 GSB 备注 6.12.26\n"
    "季节 | 年份：\n"
    "广告负责人：\n"
    "SKIP\n"
    "SKIP"
)




# ============ 翻译引擎 ============
class Translator:
    """通过 DashScope OpenAI 兼容接口调用 qwen3.6-flash 翻译 + OCR + VL页面分类"""

    def __init__(self):
        api_key = os.environ.get("DASHSCOPE_API_KEY", "")
        if not api_key:
            print("错误: 环境变量 DASHSCOPE_API_KEY 未设置")
            print("请设置: export DASHSCOPE_API_KEY=your_key")
            sys.exit(1)
        self.client = openai.OpenAI(api_key=api_key, base_url=LLM_BASE_URL)

    def classify_page(self, image_bytes: bytes) -> str:
        """
        用 VL 模型（qwen3.6-flash 多模态）判断页面类型。
        返回: 'table_spec' | 'table' | 'drawing' | 'text' | ''(失败时回退)
        """
        b64 = base64.b64encode(image_bytes).decode("utf-8")
        data_url = f"data:image/png;base64,{b64}"

        prompt = (
            "判断这个PDF页面的类型，只回答对应字母：\n"
            "A - 规格/测量表：密集的行列数据，每行一个测量项目名称+数值，如DEV SPEC、GRADED SPEC\n"
            "B - 物料清单表：BOM表格，每行描述面料/辅料信息，单元格内可能有多行文字\n"
            "C - 工艺图样：服装结构图、缝制示意图、标签设计图等\n"
            "D - 纯文字：段落式的文字描述、评审意见等\n\n"
            "只回答一个字母。"
        )

        try:
            resp = self.client.chat.completions.create(
                model=LLM_MODEL,
                messages=[{
                    "role": "user",
                    "content": [
                        {"type": "image_url", "image_url": {"url": data_url}},
                        {"type": "text", "text": prompt},
                    ],
                }],
                temperature=0.0,
                max_tokens=5,
                extra_body={"enable_thinking": False},
            )
            answer = resp.choices[0].message.content.strip().upper()
            if "A" in answer:
                return "table_spec"
            elif "B" in answer:
                return "table"
            elif "D" in answer:
                return "text"
            else:
                return "drawing"
        except Exception as e:
            print(f"  ⚠ VL分类出错: {e}")
            return ""  # 空串 → 回退规则检测

    def translate_batch(self, texts: list[str]) -> list[str]:
        """批量翻译英文文本为中文"""
        if not texts:
            return []

        # 构造批量翻译 prompt
        numbered = "\n".join(f"{i+1}. {t}" for i, t in enumerate(texts))
        prompt = (
            "将以下英文短语翻译为简洁中文，每行一个结果，只输出译文，不要编号和解释。\n"
            "规则：\n"
            "- 纯人名保持原文，输出 SKIP\n"
            "- 纯字母数字编码/型号输出 SKIP\n"
            "- 表头标签、产品描述名称、工艺说明都必须翻译\n\n"
            f"{numbered}"
        )

        try:
            resp = self.client.chat.completions.create(
                model=LLM_MODEL,
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": FEW_SHOT_USER},
                    {"role": "assistant", "content": FEW_SHOT_ASSISTANT},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.1,
                extra_body={"enable_thinking": False},
            )
            result_text = resp.choices[0].message.content.strip()
            lines = [l.strip() for l in result_text.split("\n") if l.strip()]

            # 清理可能的编号前缀
            cleaned = []
            for line in lines:
                line = re.sub(r"^\d+[\.\)、]\s*", "", line)
                cleaned.append(line)

            # 如果返回行数不匹配，尽力对齐
            if len(cleaned) >= len(texts):
                return cleaned[: len(texts)]
            else:
                # 补空
                return cleaned + [""] * (len(texts) - len(cleaned))

        except Exception as e:
            print(f"  ⚠ LLM翻译出错: {e}")
            return [""] * len(texts)

    def ocr_image(self, image_bytes: bytes) -> list[dict]:
        """
        用 OCR 模型识别图片中的文本。
        优先从 ocr_result.words_info 获取结构化数据（含 location 四角坐标），
        回退到解析 text 字段的 JSON 行。
        返回: [{"text": str, "location": [x1,y1,...,x4,y4] or None}]
        """
        b64 = base64.b64encode(image_bytes).decode("utf-8")
        data_url = f"data:image/png;base64,{b64}"

        try:
            messages = [{
                "role": "user",
                "content": [{
                    "image": data_url,
                    "min_pixels": 32 * 32 * 3,
                    "max_pixels": 32 * 32 * 8192,
                }],
            }]
            resp = MultiModalConversation.call(
                api_key=os.environ.get("DASHSCOPE_API_KEY", ""),
                model=OCR_MODEL,
                messages=messages,
                ocr_options={"task": "advanced_recognition"},
            )

            # 优先使用 ocr_result.words_info（结构化，含 location 四角坐标）
            msg_content = resp["output"]["choices"][0]["message"].content[0]
            ocr_result = msg_content.get("ocr_result") if isinstance(msg_content, dict) else None

            results = []
            if ocr_result and "words_info" in ocr_result:
                for item in ocr_result["words_info"]:
                    text = item.get("text", "").strip()
                    location = item.get("location", None)
                    if text and len(text) >= 2 and re.search(r"[a-zA-Z]", text):
                        if not is_pure_number(text):
                            results.append({"text": text, "location": location})
                return results

            # 回退：解析 text 字段的 JSON 行
            raw_text = msg_content["text"] if isinstance(msg_content, dict) else msg_content
            if not raw_text or not raw_text.strip():
                return []

            for line in raw_text.split("\n"):
                line = line.strip().rstrip(",")
                if not line or line.startswith("```") or line == "[" or line == "]":
                    continue
                try:
                    obj = json.loads(line)
                    text = obj.get("text", "").strip()
                    # 优先 location，其次 rotate_rect
                    location = obj.get("location", None)
                    if not location:
                        rect = obj.get("rotate_rect", None)
                        if rect and len(rect) >= 4:
                            # rotate_rect = [cx, cy, w, h, angle]，转为近似 location
                            cx, cy, w, h = rect[0], rect[1], rect[2], rect[3]
                            # 对于近似水平文本，w 和 h 可能互换，取较大值为文本宽度
                            tw, th = max(w, h), min(w, h)
                            x0 = cx - tw // 2
                            y0 = cy - th // 2
                            x1 = cx + tw // 2
                            y1 = cy + th // 2
                            location = [x0, y0, x1, y0, x1, y1, x0, y1]
                    if text and len(text) >= 2 and re.search(r"[a-zA-Z]", text):
                        if not is_pure_number(text):
                            results.append({"text": text, "location": location})
                except (json.JSONDecodeError, TypeError):
                    if len(line) >= 3 and re.search(r"[a-zA-Z]", line):
                        if not is_pure_number(line):
                            results.append({"text": line, "location": None})
            return results
        except Exception as e:
            print(f"  ⚠ OCR识别出错: {e}")
            return []


# ============ 文本过滤 ============
def is_footer(text: str, y_pos: float, page_height: float) -> bool:
    """判断是否为页脚（基于位置和文本结构特征，不依赖关键词枚举）"""
    # 页面底部 8% 区域 → 直接视为页脚
    if y_pos > page_height * 0.92:
        return True
    # 底部 15% 区域的短文本，检测分页/日期/法律声明等页脚模式
    if y_pos > page_height * 0.85:
        t = text.strip()
        if not t:
            return False
        # 分页模式: "Page 1 of 10", "2 / 5"
        if re.search(r'\bPage\s+\d+\s+(of|/)\s+\d+', t, re.IGNORECASE):
            return True
        if re.match(r'^\d+\s*/\s*\d+$', t):
            return True
        # 日期/时间戳模式（常见于 "Printed: 2024-01-01" 类页脚）
        if re.search(r'\d{4}[-/]\d{2}[-/]\d{2}', t):
            return True
        if re.search(r'\d{1,2}/\d{1,2}/\d{2,4}', t):
            return True
        # 短文本 + 大写比例高 → 法律/版权声明类页脚
        if len(t) < 80:
            alpha_chars = [c for c in t if c.isalpha()]
            if alpha_chars:
                upper_ratio = sum(1 for c in alpha_chars if c.isupper()) / len(alpha_chars)
                if upper_ratio > 0.7:
                    return True
    return False


def is_pure_number(text: str) -> bool:
    """纯数字/编号/尺寸/短代码/尺寸规格/金额/布尔标记/测量代码串"""
    t = text.strip()
    if not t:
        return True
    # 布尔标记 TRUE/FALSE（规格表中的状态指示，不需要翻译）
    if t.upper() in ("TRUE", "FALSE"):
        return True
    # 多个 TRUE/FALSE 组合串（如 "TRUE TRUE FALSE TRUE"）
    if all(w.upper() in ("TRUE", "FALSE") for w in t.split()):
        return True
    # 纯数字(含分隔符)
    if re.match(r"^[\d\s,.\-/x×X]+$", t):
        return True
    # TCX色号
    if re.match(r"^\d{2}-\d{4}\s*TCX$", t):
        return True
    # 短编号/代码 (如 F27, M654, PSJ0)
    if re.match(r"^[A-Z]{1,3}\d{1,4}[A-Z]?$", t):
        return True
    # 多个测量代码串 (如 "J107 J108 J120 L100 M120 N105" — 全部由短代码组成)
    tokens = t.split()
    if len(tokens) >= 3 and all(re.match(r'^[A-Z]{1,3}\d{1,4}[A-Z]?$', tok) for tok in tokens):
        return True
    # 尺码列表
    if re.match(r"^[\d,]+$", t.replace(" ", "")):
        return True
    # 尺寸/规格模式 (如 50mmx27mm, 67mm X 26mm, 31.5mmX12.5m, 50cm)
    if re.match(r"^[\d.]+\s*(mm|cm|m|in|inch|pt)\s*([xX×]\s*[\d.]+\s*(mm|cm|m|in|inch|pt))?$", t, re.IGNORECASE):
        return True
    # 数字+货币代码 (如 1.00 USD, 2.00 USD)，但排除单独货币代码(如 USD)
    if re.match(r"^[\d.]+\s*(USD|EUR|CNY|RMB|GBP|JPY)\s*[\d.]*$", t, re.IGNORECASE):
        return True
    # 货币代码+数字 (如 USD 0.0, USD 0 0)，但排除单独货币代码
    if re.match(r"^(USD|EUR|CNY|RMB|GBP|JPY)\s+[\d.\s]+$", t, re.IGNORECASE):
        return True
    return False


def has_chinese(text: str) -> bool:
    """包含中文字符"""
    return bool(re.search(r"[\u4e00-\u9fff]", text))


def is_translatable(text: str, y_pos: float, page_height: float) -> bool:
    """判断文本是否需要翻译"""
    t = text.strip()
    if len(t) < 2:
        return False
    if is_footer(t, y_pos, page_height):
        return False
    if is_pure_number(t):
        return False
    if has_chinese(t):
        return False
    # 至少包含一个英文字母
    if not re.search(r"[a-zA-Z]", t):
        return False
    return True


# ============ 空白区域检测 ============
PAGE_MARGIN = 5  # 页面安全边距，注释不得超出此范围


class SpaceDetector:
    """检测页面空白区域，避免与已有内容重叠"""

    def __init__(self, page):
        self.page = page
        self.page_rect = page.rect
        self.safe_rect = fitz.Rect(
            self.page_rect.x0 + PAGE_MARGIN,
            self.page_rect.y0 + PAGE_MARGIN,
            self.page_rect.x1 - PAGE_MARGIN,
            self.page_rect.y1 - PAGE_MARGIN,
        )
        self.occupied_text = []   # 文本块 + 已有注释
        self.occupied_images = [] # 图片块
        self._collect_occupied_areas()

    def _collect_occupied_areas(self):
        """收集页面上所有已占用区域（文本和图片分开存储）"""
        blocks = self.page.get_text("dict")["blocks"]
        for b in blocks:
            if b["type"] == 0:  # text
                self.occupied_text.append(fitz.Rect(b["bbox"]))
            elif b["type"] == 1:  # image
                self.occupied_images.append(fitz.Rect(b["bbox"]))

        for annot in self.page.annots() or []:
            self.occupied_text.append(annot.rect)

    def add_occupied(self, rect):
        """添加新的已占用区域"""
        self.occupied_text.append(rect)

    def find_position(self, origin_bbox, text_width, text_height, allow_image_overlap=False):
        """
        在原文旁边寻找空白位置。
        返回 (rect, is_compact, force_white_bg)。
        is_compact=True 表示紧凑兆底，调用方应使用最小字号。
        force_white_bg=True 表示放置位置与已有内容重叠，需添加白色背景。
        优先级：正下方 → 右侧 → 左侧 → 正上方 → 紧凑兆底
        """
        x0, y0, x1, y1 = origin_bbox
        margin = 2

        # OCR 项优先紧贴正下方，其次右侧（仅检查已放置注释，允许与图片重叠）
        if allow_image_overlap:
            # 优先正下方
            below = fitz.Rect(x0, y1 + 1, x0 + text_width, y1 + 1 + text_height)
            if self.safe_rect.contains(below):
                conflict = False
                for occ in self.occupied_text:
                    if below.intersects(occ):
                        conflict = True
                        break
                if not conflict:
                    return below, False, False
            # 其次右侧
            right = fitz.Rect(x1 + 1, y0, x1 + 1 + text_width, y0 + text_height)
            if self.safe_rect.contains(right):
                conflict = False
                for occ in self.occupied_text:
                    if right.intersects(occ):
                        conflict = True
                        break
                if not conflict:
                    return right, False, False

        # 标准四方向：下 → 右 → 左 → 上
        candidates = [
            fitz.Rect(x0, y1 + margin, x0 + text_width, y1 + margin + text_height),
            fitz.Rect(x1 + margin, y0, x1 + margin + text_width, y0 + text_height),
            fitz.Rect(x0 - margin - text_width, y0, x0 - margin, y0 + text_height),
            fitz.Rect(x0, y0 - margin - text_height, x0 + text_width, y0 - margin),
        ]

        for rect in candidates:
            if self._is_valid_position(rect, allow_image_overlap):
                return rect, False, False

        # 紧凑兆底——原文正下方紧贴（最小字号）
        compact_h = MIN_FONT_SIZE * 1.4 + 2
        compact_w = min(text_width, x1 - x0 + 20)
        compact = fitz.Rect(x0, y1, x0 + compact_w, y1 + compact_h)
        if self.safe_rect.contains(compact):
            # 检查紧凑位置是否与已有内容重叠
            has_overlap = not self._is_valid_position(compact, allow_image_overlap)
            return compact, True, has_overlap

        return None, False, False

    def _is_valid_position(self, rect: fitz.Rect, allow_image_overlap=False) -> bool:
        """检查位置是否有效（在安全区域内且不重叠）"""
        if not self.safe_rect.contains(rect):
            return False
        shrunk = fitz.Rect(rect.x0 + 1, rect.y0 + 1, rect.x1 - 1, rect.y1 - 1)
        # 始终检查文本重叠
        for occ in self.occupied_text:
            if shrunk.intersects(occ):
                return False
        # 仅在非 OCR 模式下检查图片重叠
        if not allow_image_overlap:
            for occ in self.occupied_images:
                if shrunk.intersects(occ):
                    return False
        return True


# ============ 排版计算 ============
def estimate_text_size(text: str, font_size: float) -> tuple[float, float]:
    """估算文本渲染尺寸（宽度, 高度）"""
    # china-s 字体：中文字符宽度≈字号，英文约0.6倍字号
    # 加宽系数避免 FreeText 注释内部裁剪
    char_width = 0
    for ch in text:
        if "\u4e00" <= ch <= "\u9fff":
            char_width += font_size * 1.05
        else:
            char_width += font_size * 0.6
    height = font_size * 1.3
    return char_width, height


def wrap_text(text: str, max_width: float, font_size: float) -> list[str]:
    """将长文本按最大宽度换行"""
    if not text:
        return [text]

    width, _ = estimate_text_size(text, font_size)
    if width <= max_width:
        return [text]

    # 按字符逐步分行
    lines = []
    current_line = ""
    current_width = 0

    for ch in text:
        if "\u4e00" <= ch <= "\u9fff":
            ch_w = font_size * 0.9
        else:
            ch_w = font_size * 0.5

        if current_width + ch_w > max_width and current_line:
            lines.append(current_line)
            current_line = ch
            current_width = ch_w
        else:
            current_line += ch
            current_width += ch_w

    if current_line:
        lines.append(current_line)

    return lines


def calculate_adaptive_size(
    text: str, origin_bbox, page_width: float, base_font_size: float
) -> tuple[float, float, float]:
    """
    自适应计算字号和尺寸
    返回: (font_size, width, height)
    """
    x0, y0, x1, y1 = origin_bbox
    # 可用宽度：从原文右边到页面右边缘（留余量）
    available_width = page_width - x1 - 10

    # 如果右侧空间太小，尝试用原文宽度作为可用宽度
    if available_width < 40:
        available_width = max(80, x1 - x0)

    font_size = base_font_size

    # FreeText 注释内部有约 2pt 左右内边距，额外预留缓冲
    PADDING_W = 10  # 水平方向额外空间
    PADDING_H = 4   # 垂直方向额外空间

    while font_size >= MIN_FONT_SIZE:
        lines = wrap_text(text, available_width, font_size)
        total_height = len(lines) * font_size * 1.4
        max_line_width = max(estimate_text_size(l, font_size)[0] for l in lines)
        # 检查是否合理（不超过5行）
        if len(lines) <= 5:
            return font_size, max_line_width + PADDING_W, total_height + PADDING_H
        font_size -= 0.5

    # 最小字号兜底
    lines = wrap_text(text, available_width, MIN_FONT_SIZE)
    total_height = len(lines) * MIN_FONT_SIZE * 1.4
    max_line_width = max(estimate_text_size(l, MIN_FONT_SIZE)[0] for l in lines)
    return MIN_FONT_SIZE, max_line_width + PADDING_W, total_height + PADDING_H


# ============ 主流程 ============
def detect_page_type(page, translator=None) -> str:
    """
    检测页面类型。优先用 VL 模型视觉判断（健壮），失败时回退规则检测。
    返回: 'drawing' | 'table' | 'table_spec' | 'text'
    """
    # 优先：VL 模型视觉分类
    if translator:
        pix = page.get_pixmap(matrix=fitz.Matrix(0.5, 0.5))  # 低分辨率
        img_bytes = pix.tobytes("png")
        vl_result = translator.classify_page(img_bytes)
        if vl_result:
            return vl_result

    # 回退：规则检测
    blocks = page.get_text("dict")["blocks"]
    txt_blocks = [b for b in blocks if b["type"] == 0]
    img_blocks = [b for b in blocks if b["type"] == 1]
    page_area = page.rect.width * page.rect.height
    total_lines = sum(len(b["lines"]) for b in txt_blocks)
    line_lengths = []
    for b in txt_blocks:
        for line in b["lines"]:
            text = "".join(s["text"] for s in line["spans"]).strip()
            if text:
                line_lengths.append(len(text))
    avg_line_length = sum(line_lengths) / len(line_lengths) if line_lengths else 0

    if total_lines > 40 and avg_line_length < 30:
        return "table"
    if total_lines > 15 and avg_line_length > 40:
        return "text"
    return "drawing"


def extract_translatable_texts(page, merge_gap_factor: float = 2.0) -> list[dict]:
    """提取页面中需要翻译的文本（文本层）。
    同一个 block 内，水平位置重叠且垂直相邻的多行文本合并为一个翻译单元
    （对应同一个表格单元格）。
    merge_gap_factor: 合并垂直间距阈值系数。表格页用 0.3（仅合并同单元格内紧贴的多行），
                      其他页用 2.0（默认，允许较大间距合并）。
    """
    page_height = page.rect.height
    blocks = page.get_text("dict")["blocks"]
    items = []

    def x_overlap_ratio(a, b):
        """两个 x 区间的重叠占较短区间的比例"""
        ax0, ax1 = a
        bx0, bx1 = b
        inter = max(0, min(ax1, bx1) - max(ax0, bx0))
        shorter = min(ax1 - ax0, bx1 - bx0)
        if shorter <= 0:
            return 0
        return inter / shorter

    for block in blocks:
        if block["type"] != 0:
            continue

        # 收集非空行
        block_lines = []
        for line in block["lines"]:
            spans = line["spans"]
            t = "".join(s["text"] for s in spans).strip()
            if not t:
                continue
            bbox = line["bbox"]
            size = spans[0]["size"] if spans else 8

            # 拆分“小数数字 + 空格 + 英文”模式（表格页中Price列与Placement列共享同一行）
            split_m = re.match(r'^([\d.$]+\s+)(\S.*)$', t)
            if split_m:
                num_part = split_m.group(1).strip()
                text_part = split_m.group(2).strip()
                # 仅当前缀是纯数字/货币值且后续含字母时才拆分
                if is_pure_number(num_part) and re.search(r'[a-zA-Z]', text_part):
                    # 数字部分会被 is_translatable 过滤，只保留文字部分
                    # 估算文字部分的x位置（假设数字占对应宽度比例）
                    num_ratio = len(split_m.group(1)) / max(len(t), 1)
                    x_offset = (bbox[2] - bbox[0]) * num_ratio
                    text_bbox = (bbox[0] + x_offset, bbox[1], bbox[2], bbox[3])
                    block_lines.append({
                        "text": text_part,
                        "bbox": text_bbox,
                        "size": size,
                    })
                    continue

            block_lines.append({
                "text": t,
                "bbox": bbox,
                "size": size,
            })

        if not block_lines:
            continue

        # 按垂直位置排序
        block_lines.sort(key=lambda l: (l["bbox"][1], l["bbox"][0]))

        # 分组：与现有任意分组中任一行 x 重叠·60% 且 y 距离 ≤ merge_gap_factor×行高的则合并
        groups = []  # 每个元素是一个 line list
        for line in block_lines:
            lx = (line["bbox"][0], line["bbox"][2])
            ly0, ly1 = line["bbox"][1], line["bbox"][3]
            line_h = max(ly1 - ly0, 1)
            placed = False
            for g in groups:
                # 检查是否与该组中某行同列且相邻
                for gl in g:
                    gx = (gl["bbox"][0], gl["bbox"][2])
                    gy0, gy1 = gl["bbox"][1], gl["bbox"][3]
                    gline_h = max(gy1 - gy0, 1)
                    max_h = max(line_h, gline_h)
                    # 垂直距离（边距）
                    v_gap = max(0, max(ly0, gy0) - min(ly1, gy1))
                    if x_overlap_ratio(lx, gx) >= 0.6 and v_gap <= merge_gap_factor * max_h:
                        g.append(line)
                        placed = True
                        break
                if placed:
                    break
            if not placed:
                groups.append([line])

        # 每个组生成一个合并项
        for g in groups:
            g.sort(key=lambda l: (l["bbox"][1], l["bbox"][0]))
            merged_text = " ".join(l["text"] for l in g)
            x0 = min(l["bbox"][0] for l in g)
            y0 = min(l["bbox"][1] for l in g)
            x1 = max(l["bbox"][2] for l in g)
            y1 = max(l["bbox"][3] for l in g)
            bbox = (x0, y0, x1, y1)
            font_size = g[0]["size"]
            y_center = (y0 + y1) / 2

            if is_translatable(merged_text, y_center, page_height):
                items.append({
                    "text": merged_text,
                    "bbox": bbox,
                    "size": font_size,
                })

    return _merge_cross_block_items(items)


def _merge_cross_block_items(items: list[dict]) -> list[dict]:
    """跨 block 合并：将空间近乎相接的同列文本合并为一个翻译单元。
    仅合并间距极小（< 单行高度15%）的项，适用于同一单元格被PDF拆到不同block的情况。
    使用字号而非bbox高度判断，避免多行合并体的高度误导合并决策。
    """
    if len(items) <= 1:
        return items

    def x_overlap_ratio(a, b):
        ax0, ax1 = a
        bx0, bx1 = b
        inter = max(0, min(ax1, bx1) - max(ax0, bx0))
        shorter = min(ax1 - ax0, bx1 - bx0)
        if shorter <= 0:
            return 0
        return inter / shorter

    # 按垂直位置排序
    sorted_items = sorted(items, key=lambda it: (it["bbox"][1], it["bbox"][0]))

    groups = []  # 每个元素是 item list
    for item in sorted_items:
        ix = (item["bbox"][0], item["bbox"][2])
        iy0, iy1 = item["bbox"][1], item["bbox"][3]
        item_size = item.get("size", 8)
        placed = False
        for g in groups:
            for gi in g:
                gx = (gi["bbox"][0], gi["bbox"][2])
                gy0, gy1 = gi["bbox"][1], gi["bbox"][3]
                gi_size = gi.get("size", 8)

                v_gap = max(0, max(iy0, gy0) - min(iy1, gy1))

                # 基于字号估计单行高度，仅合并近乎相接的项
                # 同一单元格被拆分到不同block时，行间距通常 < 1pt
                # 不同单元格（表格行）之间间距通常 >= 2pt
                min_line_h = min(item_size, gi_size) * 1.4
                size_ratio = max(item_size, gi_size) / max(min(item_size, gi_size), 1)

                if size_ratio <= 1.8 and x_overlap_ratio(ix, gx) >= 0.6 and v_gap <= min_line_h * 0.15:
                    g.append(item)
                    placed = True
                    break
            if placed:
                break
        if not placed:
            groups.append([item])

    merged = []
    for g in groups:
        if len(g) == 1:
            merged.append(g[0])
        else:
            g.sort(key=lambda it: (it["bbox"][1], it["bbox"][0]))
            text = " ".join(it["text"] for it in g)
            x0 = min(it["bbox"][0] for it in g)
            y0 = min(it["bbox"][1] for it in g)
            x1 = max(it["bbox"][2] for it in g)
            y1 = max(it["bbox"][3] for it in g)
            merged.append({
                "text": text,
                "bbox": (x0, y0, x1, y1),
                "size": g[0]["size"],
            })
    return merged


def extract_table_texts(page) -> list[dict]:
    """表格页专用提取：逐行提取，不合并。每个 line 独立作为一个翻译单元。"""
    page_height = page.rect.height
    blocks = page.get_text("dict")["blocks"]
    items = []

    for block in blocks:
        if block["type"] != 0:
            continue
        for line in block["lines"]:
            spans = line["spans"]
            text = "".join(s["text"] for s in spans).strip()
            if not text:
                continue
            bbox = line["bbox"]
            y_center = (bbox[1] + bbox[3]) / 2
            if is_translatable(text, y_center, page_height):
                items.append({
                    "text": text,
                    "bbox": bbox,
                    "size": spans[0]["size"] if spans else 8,
                })

    return items


def _group_nearby_items(raw_items: list[dict]) -> list[dict]:
    """将空间上相邻的 OCR 文本合并为一个翻译单元（同一个标注框/图例内的多行）。"""
    if not raw_items:
        return []

    def x_overlap_ratio(a, b):
        ax0, ax1 = a
        bx0, bx1 = b
        inter = max(0, min(ax1, bx1) - max(ax0, bx0))
        shorter = min(ax1 - ax0, bx1 - bx0)
        if shorter <= 0:
            return 0
        return inter / shorter

    # 按垂直位置排序
    sorted_items = sorted(raw_items, key=lambda it: (it["bbox"][1], it["bbox"][0]))

    groups = []  # 每个元素是 item list
    for item in sorted_items:
        ix = (item["bbox"][0], item["bbox"][2])
        iy0, iy1 = item["bbox"][1], item["bbox"][3]
        item_h = max(iy1 - iy0, 1)
        placed = False
        for g in groups:
            for gi in g:
                gx = (gi["bbox"][0], gi["bbox"][2])
                gy0, gy1 = gi["bbox"][1], gi["bbox"][3]
                gi_h = max(gy1 - gy0, 1)
                max_h = max(item_h, gi_h)
                v_gap = max(0, max(iy0, gy0) - min(iy1, gy1))
                # 高度比检查：字号差异大的不合并（如标题 vs 正文）
                h_ratio = max(item_h, gi_h) / min(item_h, gi_h)
                if h_ratio <= 1.8 and x_overlap_ratio(ix, gx) >= 0.5 and v_gap <= 2.0 * max_h:
                    g.append(item)
                    placed = True
                    break
            if placed:
                break
        if not placed:
            groups.append([item])

    merged = []
    for g in groups:
        g.sort(key=lambda it: (it["bbox"][1], it["bbox"][0]))
        text = " ".join(it["text"] for it in g)
        x0 = min(it["bbox"][0] for it in g)
        y0 = min(it["bbox"][1] for it in g)
        x1 = max(it["bbox"][2] for it in g)
        y1 = max(it["bbox"][3] for it in g)
        merged.append({
            "text": text,
            "bbox": (x0, y0, x1, y1),
            "size": g[0].get("size", 8),
            "source": "ocr",
        })
    return merged


def extract_ocr_texts(page, translator) -> list[dict]:
    """
    对页面中的图片区域进行 OCR，提取图片内嵌的英文文本。
    使用 qwen3.5-ocr 专用模型，返回带精确坐标的 items。
    空间相邻的多行文本会自动合并为一个翻译单元。
    标签设计页/照片页/色卡页跳过 OCR（图片是产品设计内容）。
    """
    # 基于页面结构特征判断是否跳过 OCR：
    # 当页面文本层已经内容丰富且存在多个图片块时，图片很可能是产品设计稿/标签/色卡
    # 等展示性内容，不需要 OCR 识别其中的文字
    blocks = page.get_text("dict")["blocks"]
    txt_blocks_check = [b for b in blocks if b["type"] == 0]
    img_blocks_check = [b for b in blocks if b["type"] == 1]
    text_lines_count = sum(len(b["lines"]) for b in txt_blocks_check)
    # 文本层丰富 + 多图片 → 图片是产品展示内容，跳过 OCR
    if text_lines_count > 20 and len(img_blocks_check) >= 3:
        return []

    blocks = page.get_text("dict")["blocks"]
    image_blocks = [b for b in blocks if b["type"] == 1]

    if not image_blocks:
        return []

    page_height = page.rect.height
    raw_items = []
    scale = 2  # 渲染放大倍数

    for img_block in image_blocks:
        bbox = img_block["bbox"]
        img_rect = fitz.Rect(bbox)

        # 跳过太小的图片（可能是图标/色块/标签设计稿）
        # 只对占页面宽度 40% 以上或高度 40% 以上的大图做 OCR（工艺图/结构图）
        page_width = page.rect.width
        if img_rect.width < page_width * 0.4 and img_rect.height < page_height * 0.4:
            continue

        # 渲染图片区域为 PNG
        mat = fitz.Matrix(scale, scale)
        try:
            pix = page.get_pixmap(matrix=mat, clip=img_rect)
            img_bytes = pix.tobytes("png")
        except Exception:
            continue

        # 调用 OCR
        ocr_results = translator.ocr_image(img_bytes)

        if not ocr_results:
            continue

        for ocr_item in ocr_results:
            text = ocr_item["text"]
            location = ocr_item.get("location")  # [x1,y1,x2,y2,x3,y3,x4,y4] 像素坐标

            if not is_translatable(text, bbox[1], page_height):
                continue

            # 如果有精确坐标，转换为 PDF 页面坐标
            if location and len(location) >= 8:
                # location = [x1,y1, x2,y2, x3,y3, x4,y4]
                # 左上→右上→右下→左下，取边界框
                xs = [location[i] for i in range(0, 8, 2)]
                ys = [location[i] for i in range(1, 8, 2)]
                px0, py0, px1, py1 = min(xs), min(ys), max(xs), max(ys)
                # 像素坐标 → PDF坐标（考虑 clip 偏移 + 缩放）
                pdf_x0 = img_rect.x0 + px0 / scale
                pdf_y0 = img_rect.y0 + py0 / scale
                pdf_x1 = img_rect.x0 + px1 / scale
                pdf_y1 = img_rect.y0 + py1 / scale
                item_bbox = (pdf_x0, pdf_y0, pdf_x1, pdf_y1)
            else:
                # 无坐标则使用图片 bbox 中心
                cx = (bbox[0] + bbox[2]) / 2
                cy = (bbox[1] + bbox[3]) / 2
                item_bbox = (cx - 20, cy - 5, cx + 20, cy + 5)

            raw_items.append({
                "text": text,
                "bbox": item_bbox,
                "size": 8,
                "source": "ocr",
            })

    # 合并空间相邻的 OCR 文本
    return _group_nearby_items(raw_items)


def process_page(page, translations: dict[str, str], font_size: float, preview: bool, items: list[dict] = None, page_type: str = "drawing"):
    """处理单页：添加翻译注释。page_type 影响放置策略。"""
    detector = SpaceDetector(page)
    page_width = page.rect.width
    added = 0

    if items is None:
        items = extract_translatable_texts(page)

    for item in items:
        text = item["text"]
        translation = translations.get(text, "")
        if not translation:
            continue

        # 自适应计算尺寸
        fs, width, height = calculate_adaptive_size(
            translation, item["bbox"], page_width, font_size
        )

        # 根据页面类型选择放置策略
        is_ocr = item.get("source") == "ocr"

        # 如果原文本身与图片重叠，则允许译文也放在图片上方（与OCR同等待遇）
        if not is_ocr:
            origin_rect = fitz.Rect(item["bbox"])
            for img_occ in detector.occupied_images:
                if origin_rect.intersects(img_occ):
                    is_ocr = True
                    break

        if page_type in ("table", "table_spec"):
            # 表格页：用小字体FreeText塞在右侧空白处，允许多行换行
            x0, y0, x1, y1 = item["bbox"]
            margin = 2
            table_fs = MIN_FONT_SIZE
            # 右侧可用空间
            right_space = page_width - x1 - PAGE_MARGIN - margin
            pos = None
            use_white_bg = False  # 默认透明背景，仅重叠时加白色背景

            if right_space >= 20:
                # 优先用小字体塞右边，自适应宽度：取到右侧最近占用区域的距离作为最大宽度
                # 检测右侧最近的占用区域（与当前行 y 范围重叠的）
                # 同时限制最大宽度不超过原文宽度的1.5倍，避免译文无限延伸
                origin_width = x1 - x0
                gap_to_right = right_space
                for occ in detector.occupied_text:
                    if occ.x0 > x1 and occ.y0 < y1 and occ.y1 > y0:  # 右侧且同行
                        gap = occ.x0 - x1 - margin * 2
                        if gap > 10 and gap < gap_to_right:
                            gap_to_right = gap
                width_cap = max(origin_width * 1.5, 60)
                max_wrap_w = max(min(gap_to_right, right_space, width_cap), 40)
                lines = wrap_text(translation, max_wrap_w, table_fs)
                t_height = len(lines) * table_fs * 1.4 + (2 if len(lines) == 1 else 4)
                max_line_w = max(estimate_text_size(l, table_fs)[0] for l in lines)
                candidate = fitz.Rect(x1 + margin, y0, x1 + margin + max_line_w + 4, y0 + t_height)
                if detector.safe_rect.contains(candidate) and detector._is_valid_position(candidate, False):
                    pos = candidate

            if pos is None and right_space >= 20:
                # 右侧有空间但与相邻列冲突 → 白底强制右侧放置，同样自适应宽度
                origin_width = x1 - x0
                gap_to_right = right_space
                for occ in detector.occupied_text:
                    if occ.x0 > x1 and occ.y0 < y1 and occ.y1 > y0:
                        gap = occ.x0 - x1 - margin * 2
                        if gap > 10 and gap < gap_to_right:
                            gap_to_right = gap
                width_cap = max(origin_width * 1.5, 60)
                max_wrap_w = max(min(gap_to_right, right_space, width_cap), 40)
                lines = wrap_text(translation, max_wrap_w, table_fs)
                t_height = len(lines) * table_fs * 1.4 + (2 if len(lines) == 1 else 4)
                max_line_w = max(estimate_text_size(l, table_fs)[0] for l in lines)
                candidate = fitz.Rect(x1 + margin, y0, x1 + margin + max_line_w + 4, y0 + t_height)
                if detector.safe_rect.contains(candidate):
                    pos = candidate
                    use_white_bg = True

            if pos is None:
                # 所有不重叠策略失败 → 强制放置在下方，加白色背景保证可读性
                col_width = max(40, x1 - x0 + 10)
                lines = wrap_text(translation, col_width, table_fs)
                t_height = len(lines) * table_fs * 1.4 + (2 if len(lines) == 1 else 4)
                pos = fitz.Rect(x0, y1 + 0.5, x0 + col_width, y1 + 0.5 + t_height)
                if not detector.safe_rect.contains(pos):
                    # 裁剪到安全区域
                    pos = pos & detector.safe_rect
                    if pos.is_empty:
                        continue
                use_white_bg = True

            if not preview:
                display_text = "\n".join(lines)
                # 表格页统一加白底：表格网格线是矢量路径，无法被SpaceDetector检测，
                # 不加白底会导致红色译文被表格线遮挡
                bg_color = (1, 1, 1)
                annot = page.add_freetext_annot(
                    pos,
                    display_text,
                    fontsize=table_fs,
                    fontname=ANNOTATION_FONT,
                    text_color=RED_COLOR,
                    fill_color=bg_color,
                    border_color=None,
                )
                annot.update(fill_color=bg_color, border_color=None)

            detector.add_occupied(pos)
            added += 1
            continue
        elif page_type == "text":
            # 纯文字页：右侧优先（紧跟原文后方），然后下方
            x0, y0, x1, y1 = item["bbox"]
            margin = 2
            candidates = [
                fitz.Rect(x1 + margin, y0, x1 + margin + width, y0 + height),
                fitz.Rect(x0, y1 + margin, x0 + width, y1 + margin + height),
            ]
            pos = None
            force_white_bg = False
            for rect in candidates:
                if detector._is_valid_position(rect, False):
                    pos = rect
                    break
            if pos is None:
                # 兆底：紧凑下方
                compact_h = MIN_FONT_SIZE * 1.4 + 2
                compact_w = min(width, x1 - x0 + 20)
                pos = fitz.Rect(x0, y1, x0 + compact_w, y1 + compact_h)
                if not detector.safe_rect.contains(pos):
                    continue
                fs = MIN_FONT_SIZE
                width = pos.width
                # 检查紧凑位置是否重叠，重叠时加白色背景
                if not detector._is_valid_position(pos, False):
                    force_white_bg = True
            is_compact = False
        else:
            # 图样页 / skip 页：使用原有逻辑
            pos, is_compact, force_white_bg = detector.find_position(item["bbox"], width, height, allow_image_overlap=is_ocr)
            if pos is None:
                continue

        # 紧凑模式：使用最小字号
        if is_compact:
            fs = MIN_FONT_SIZE
            width = pos.width

        if not preview:
            # 换行处理
            lines = wrap_text(translation, width - 10, fs)
            display_text = "\n".join(lines)

            bg_color = (1, 1, 1) if force_white_bg else None
            annot = page.add_freetext_annot(
                pos,
                display_text,
                fontsize=fs,
                fontname=ANNOTATION_FONT,
                text_color=RED_COLOR,
                fill_color=bg_color,
                border_color=None,
            )
            annot.update(fill_color=bg_color, border_color=None)

        detector.add_occupied(pos)
        added += 1

    return added


def parse_pages(pages_str: str, total: int) -> list[int]:
    """解析页码参数，返回0-indexed页码列表"""
    if not pages_str:
        return list(range(total))

    result = set()
    for part in pages_str.split(","):
        part = part.strip()
        if "-" in part:
            start, end = part.split("-", 1)
            start = max(1, int(start))
            end = min(total, int(end))
            result.update(range(start - 1, end))
        else:
            p = int(part) - 1
            if 0 <= p < total:
                result.add(p)

    return sorted(result)


def main():
    parser = argparse.ArgumentParser(description="PDF英文翻译标注工具")
    parser.add_argument("input", help="输入PDF文件路径")
    parser.add_argument("--output", "-o", help="输出PDF路径")
    parser.add_argument("--pages", "-p", help="页码范围 (如 1-5 或 1,3,5)")
    parser.add_argument("--font-size", "-fs", type=float, default=DEFAULT_FONT_SIZE)
    parser.add_argument("--preview", action="store_true", help="仅预览不写入")
    parser.add_argument("--batch-size", type=int, default=20, help="LLM批量翻译条数")
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"错误: 文件不存在: {input_path}")
        sys.exit(1)

    output_path = args.output or str(input_path.stem) + "_translated.pdf"

    # 初始化翻译器
    print("初始化翻译引擎...")
    translator = Translator()

    # 打开PDF
    doc = fitz.open(str(input_path))
    total_pages = len(doc)
    pages = parse_pages(args.pages, total_pages)
    print(f"打开: {input_path.name} ({total_pages}页)")
    print(f"处理页面: {[p+1 for p in pages]}")

    # 第一遍：提取所有待翻译文本（文本层 + OCR图片层）
    print("\n[1/4] 提取待翻译文本...")
    all_texts = {}  # text -> set of page numbers
    page_items = {}  # page_num -> items list
    page_types = {}  # page_num -> page_type

    for page_num in pages:
        page = doc[page_num]
        pt = detect_page_type(page, translator)
        page_types[page_num] = pt

        if pt == "table_spec":
            items = extract_table_texts(page)  # SPEC规格表：逐行提取，每行独立翻译
        elif pt == "table":
            items = extract_translatable_texts(page)  # BOM物料表：单元格内多行合并
        else:
            items = extract_translatable_texts(page)  # 图样/文字页：带合并

        page_items[page_num] = items
        for item in items:
            if item["text"] not in all_texts:
                all_texts[item["text"]] = set()
            all_texts[item["text"]].add(page_num)

    text_count = len(all_texts)
    print(f"  文本层: {text_count} 条唯一文本")

    # OCR：仅对图样页识别图片中的英文文本
    print("\n[2/4] OCR识别图片内文本...")
    for page_num in pages:
        if page_types[page_num] != "drawing":
            continue
        page = doc[page_num]
        ocr_items = extract_ocr_texts(page, translator)
        if ocr_items:
            page_items[page_num].extend(ocr_items)
            for item in ocr_items:
                if item["text"] not in all_texts:
                    all_texts[item["text"]] = set()
                all_texts[item["text"]].add(page_num)
            print(f"  第{page_num+1}页: OCR发现 {len(ocr_items)} 条")

    ocr_count = len(all_texts) - text_count
    unique_texts = list(all_texts.keys())
    print(f"  OCR新增: {ocr_count} 条，合计: {len(unique_texts)} 条唯一文本")
    print()

    if args.preview:
        print("[预览模式] 待翻译内容:")
        for i, t in enumerate(unique_texts[:50], 1):
            print(f"  {i}. {t}")
        if len(unique_texts) > 50:
            print(f"  ... 还有 {len(unique_texts)-50} 条")
        doc.close()
        return

    # 第三步：批量翻译
    print("[3/4] 调用LLM翻译...")
    translations = {}
    batch_size = args.batch_size

    for i in range(0, len(unique_texts), batch_size):
        batch = unique_texts[i: i + batch_size]
        print(f"  翻译 {i+1}-{min(i+batch_size, len(unique_texts))}/{len(unique_texts)}...")
        results = translator.translate_batch(batch)
        for text, trans in zip(batch, results):
            if trans and trans.upper() != "SKIP":
                # 校验翻译结果必须包含中文，避免LLM返回英文小写版本作为“翻译”
                if has_chinese(trans):
                    translations[text] = trans

    print(f"  翻译完成: {len(translations)}/{len(unique_texts)} 条")

    # 第四步：写入注释
    print("\n[4/4] 写入FreeText注释...")
    total_added = 0

    for page_num in pages:
        page = doc[page_num]
        items = page_items.get(page_num, [])
        pt = page_types.get(page_num, "drawing")
        added = process_page(page, translations, args.font_size, preview=False, items=items, page_type=pt)
        total_added += added
        print(f"  第{page_num+1}页[{pt}]: +{added}条注释")

    # 保存
    doc.save(output_path)
    doc.close()
    print(f"\n✓ 完成! 共添加 {total_added} 条翻译注释")
    print(f"  输出: {output_path}")


if __name__ == "__main__":
    main()
